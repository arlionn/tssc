[![Project Status: Active - The project has reached a stable, usable state and is being actively developed.](http://www.repostatus.org/badges/latest/active.svg)](http://www.repostatus.org/#active)

# Mata classes for HTML tags/attributes
Contains Mata classes for HTML tags and attributes defined at [http://www.w3schools.com/tags](http://www.w3schools.com/tags).  

 
