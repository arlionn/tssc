# qlean

A clean graph scheme for Stata.

![](http://ww4.sinaimg.cn/large/abb3ee10gw1f43ahrcqomj20py0ivjt0.jpg)

![](http://ww2.sinaimg.cn/large/abb3ee10gw1f43ahncurhj20py0iv0tf.jpg)

![](http://ww2.sinaimg.cn/large/abb3ee10gw1f43ahtyxvmj20py0ivgnd.jpg)

![](http://ww1.sinaimg.cn/large/abb3ee10gw1f43ahjjhcjj20py0iv415.jpg)

![](http://ww2.sinaimg.cn/large/abb3ee10gw1f43ahlly9uj20py0ivdgx.jpg)

![](http://ww3.sinaimg.cn/large/abb3ee10gw1f43ahpde32j20py0ivt9a.jpg)
