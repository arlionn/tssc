# EDA (Exploratory Data Analysis)

Stata program that automates the generation of exploratory data analysis reports.  The program classifies variables as categorical/continuous variables and uses this information to define what types of graphs and tables to use.








