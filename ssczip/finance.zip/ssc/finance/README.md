finance<img src="https://czxa.github.io/finance/assets/finance-fit.png" align="right" />
========================================================
[![](https://img.shields.io/badge/build-passing-brightgreen.svg?style=plastic)](https:czxa.top) [![](https://img.shields.io/badge/Stata-finance-brightgreen.svg?style=plastic)](https://czxa.top) [![](https://img.shields.io/badge/github-Stata-orange.svg?style=plastic)](https://czxa.top) [![](https://img.shields.io/badge/platform-Windows_OS|Mac_OS-orange.svg?style=plastic)](https://czxa.top)

我经常会在平常的学习和工作中写一些 Stata 的小命令，为了便于整理和安装，我把它们整理成了一个命令包，由于里面有很多是关于金融数据获取和处理的，所以我将这个命令包命名为 `finance` 。里面还包含了一些绘图、其它数据获取整理的小命令。

安装
--------

Stata 提供了一种安装外部命令的基础命令：`net install`，你可以在 Stata 的命令输出窗口输入下面的命令安装 `finance` 命令：

```stata
net install finance, from("https://czxa.github.io/finance")
```

但是由于 `finance` 命令依赖于一些其它的外部命令，推荐使用 [E. F. Haghish](https://github.com/haghish) 开发的 [github](https://github.com/haghish/github) 命令安装：

首先你需要安装github命令：

```stata
net install github, from("https://haghish.github.io/github/")
```

然后就可以安装这个命令了：

```stata
github install czxa/finance, replace
```

帮助文档
--------

[FINANCE：Stata 中的金融工具包](https://czxa.github.io/finance/finance-paper/finance.pdf)


致谢
-----

> HAGHISH E F. github: a module for building, searching, installing, managing, and mining stata packages from github[EB/OL].https://github.com/haghish/github.

> MATSUOKA W. Stata and the twitter api (part ii)[EB/OL]. http://www.wmatsuoka.com/stata/stata-and-the-twitter-api-part-ii.

> WADA R. ’outreg2’: module to arrange regression outputs into an illustrative table[EB/OL]. http://fmwww.bc.edu/RePEc/bocode/o.

> ZHANG X, 2014. Importing chinese historical stock market quotations from netease[J/OL]. Stata Journal, 14(2):381-388(8).http://www.stata-journal.com/article.html?article=dm0074.

------------

<h4 align="center">

License

</h4>

<h6 align="center">

MIT © czxa.top

</h6>
